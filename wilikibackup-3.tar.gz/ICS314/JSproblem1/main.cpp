#include<iostream>
#include<vector>

int main(){
	int c3;
	int c5;
	int sum = 0;	

	std::vector<int> ans;

	for(int i = 1;i < 1000;++i){
		c3 = i % 3;
		c5 = i % 5;

		if(c3 == 0 || c5 == 0){ 
			ans.push_back(i);
			std::cout<<i<<std::endl;
		}
	}

	for(int i = 0;i < ans.size(); ++i){
		sum += ans[i];
	}

	std::cout<<sum<<std::endl;

	return 0;
}
