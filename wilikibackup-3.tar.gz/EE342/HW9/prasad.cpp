#include<iostream>
#include<vector>
#include<cstdlib>
#include<unistd.h>


int flip_coin(float bias);
int flip_coins(int n);
void k_iterations(int k);

int main(){

	k_iterations(1000);	

}


int flip_coin(float bias){

	if(bias == 0) return 0;
	else if(bias == 1) return 1;
	else{
		float p = bias;
		srand(time(NULL));
		int coin = rand() % 100;
		p *= 100;
		if(coin < (int)p) return 0;
		else return 1;
	}
}

int flip_coins(int n){
	int check = 0;
	for(int i = 0; i < n ; i++ ){
		sleep(1);
		if(flip_coin(0.5) == 1){
			check++;
		}
	}
	return check;
}

void k_iterations(int k){
	std::vector<int> n;
	for(int i = 0; i < k; i++){
		n.push_back(flip_coins(10));
	}
	int average = 0;
	for(int i = 0; i < n.size(); i++){	
		average += n[i];
	}
	std::cout<< average/n.size() <<std::endl;
}
