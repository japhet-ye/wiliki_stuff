#include<stdio.h>


int main(){
	int x = 128;
	
	printf("dec: %d\nhex: %x\n",x,x);

	return 0;
}
