int identity( int m[][M], int N)
