void swap( float *x, float *y);

void swap_big(float *a, float *b);

void reorder(float *a, float *b, float *c);
