float max ( float n1, float n2){

    if ( n1 > n2 ){
	return n1;
	}
    else {
	return n2;
    }	
}

float min ( float n1, float n2){

    if ( n1 < n2 ){

	return n1;
    }

    else{
	
	return n2;
    }
}
