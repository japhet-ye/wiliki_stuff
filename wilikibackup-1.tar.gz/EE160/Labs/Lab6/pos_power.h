float pos_power ( float x, float y);
