float avg( int a[], int i);
