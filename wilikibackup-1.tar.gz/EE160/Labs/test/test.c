

//testing whether or not the computer can read -(-b) = +b

#include<stdio.h>

int main()

{
	float b;
	
	printf("Enter number\n");
	scanf("%f", &b);

	b = -b; 

	printf("%f b \n", b);



}

