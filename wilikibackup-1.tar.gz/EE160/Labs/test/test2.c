//test power function
//


#include<stdio.h>
#include<math.h>

int main()

{

	float a;


	printf("Enter Digit\n");

	scanf("%f", a);

	a = pow(a , 2);

	printf("%f\n", a);

}


	
