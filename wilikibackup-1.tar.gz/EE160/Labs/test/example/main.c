#include<stdio.h>

int main(){
    int x;
    scanf("%d",&x);
    printf("Hello World\n");
    printf("%d\n",x);
}