//Japhet Ye
//September 14, 2016
//J Sqaured
//This program counts down from 10 until 1

#include<stdio.h>

int main(){
	int c = 10;

	printf("%d \n", c);

	while ( c > 0) {
	c = c - 1;
	printf("%d \n", c);
	}

	return 0;

}

	
