

/*	filename: min.c
 *	author: Sam Amonette
 *	team: js
 *	username: amonette
 *	date: 11-17-16
	Input: an array of grades
	Output: min or -1 if there is error*/

double min(a[],NST)
{
	float min = a[0]
	int i;
	for (i = 1;i<=NST;i++);
	{
		if a[i]<min
		{
			a[i] = min;
		}
	}	
	return min;
}
