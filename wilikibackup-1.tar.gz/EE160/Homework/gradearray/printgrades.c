




/*	filename: printgrades.c
 *	author: Sam Amonette
 *	team: js
 *	username: amonette
 *	date: 11-17-16
	Input: an array of grades. She said make it accept no input, but that is rediculous. So I made it accept the array of grades.
	Output: none*/
#include "grades.h"
void total(double a[],int NST)
{
	for (int i=0;i<NST;i++)
		printf("%.2f.) "i,a[i])
}
