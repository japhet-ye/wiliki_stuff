


int extractgrades(char name[], double grades[], int NST, int CHAR);

char assaignletter(double points);

double avg(double grades[], int start, int end);

double min( double grades[], int start, int end);

double max( double grades[], int start, int end);

double stddev( double a[], int NST);

double total( double a[], int NST);


