
/*	Filename: driver1.c
	Author: Sam Amonette
	Team: SJ^2
	username: amonette
	Date: 10-2-16
	
	Description: test for julian.c
*/

#include <stdio.h>
#include "julian.h"

int main()
{
	printf("Ordinal day number is %d\n",julian(15,5,2016));
}
