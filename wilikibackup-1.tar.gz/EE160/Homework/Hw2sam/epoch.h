


/*	Filename: epoch.h
	Author: Sam Amonette
	Team: SJ^2
	username: amonette
	Date: 10-2-16
*/

#include <stdio.h>
#include "julian.h"
double secs_since_epoch(int day, int month, int year, int hour, int minute, int second);
