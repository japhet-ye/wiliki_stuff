#include <stdio.h>

int main()
{
	printf("asdfjsdlkfjasldkfjslkdjflskdjflskdjflaksdjflsadjf\
		lskdjflkadjfl;sakdjfl;skdjf;lksjdflskajdfaslkjsdf\n");
	int x, y;
	x = 4;
	y = x + x*x \
		+ x;
}
