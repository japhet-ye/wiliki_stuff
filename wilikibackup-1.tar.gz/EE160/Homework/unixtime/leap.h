int is_leap(int year);
//this funtion determines whether or not the year is a leap year or not
