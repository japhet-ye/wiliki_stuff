main()
{
printf("I'm in directory Room100A\n");
}
