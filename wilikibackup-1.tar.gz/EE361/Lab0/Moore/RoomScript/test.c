main()

{ 
printf("Running test.c program\n");
}
