#include "hello.h"

void invokehello2()
{
hello2();
}

void hello2()
{
printf("Hello world -- Part 2\n");
}
 
