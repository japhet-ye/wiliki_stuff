// Prototypes of 6 functions

#include<stdio.h>

void invokehello1();
void invokehello2();
void invokehello3();
void hello1();
void hello2();
void hello3();

