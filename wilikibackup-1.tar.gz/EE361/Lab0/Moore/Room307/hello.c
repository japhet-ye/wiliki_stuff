#include "hello.h"

main()
{
invokehello1();
invokehello2();
invokehello3();
}
