#include "hello.h"

void invokehello3()
{
hello3();
}

void hello3()
{
printf("Hello world -- Part 3\n");
}
 
