#include "hello.h"

void invokehello1()
{
hello1();
}

void hello1()
{
printf("Hello world -- Part 1\n");
}
 
