#!/bin/bash

echo goodbye 
sleep 10
exit
