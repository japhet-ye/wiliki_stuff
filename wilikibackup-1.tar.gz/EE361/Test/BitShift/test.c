#include<stdio.h>

int main(){

	int a = 27;

	a = a << 2;

	printf("%x, %d\n",a,a);
	return 0;

}
